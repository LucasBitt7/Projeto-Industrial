# T3 — CCM1 a CCM6 — AUDITORIA FINAL (rodadas 2 a 5)

Auditoria técnica independente do CCM4 entregue na 1ª rodada. Backups preservados: `*_v1_BACKUP` (1ª rodada) e `*_v2_BACKUP` (2ª rodada: planilha `T3_CCM4_Planilha_de_Calculo_v2_BACKUP.xlsx` e `T3-Memorial de Calculo_REV_CCM4_v2_BACKUP.docx`). Nenhum arquivo CAD foi alterado (o DWG foi lido apenas em uma cópia temporária, já apagada).

**Resposta objetiva: SIM COM RESSALVAS** (CCM1 a CCM6) — ver o final.

## 0B. 5ª RODADA — CCM1, CCM2, CCM3 E CCM6 (RESTANTE DO T3)

Pedido: *gerar o restante dos CCMs (o colega havia iniciado alguns no docx, mas desconsiderar) e atualizar tudo*. Entraram **na mesma planilha** os CCM1, CCM2, CCM3 e CCM6 (abas de prefixo `C1_`, `C2_`, `C3_`, `C6_`; mesma estrutura de abas 1–14 do CCM4/CCM5) e, no memorial, as **seções 13 (CCM1), 14 (CCM2), 15 (CCM3) e 16 (CCM6)**, geradas dos valores recalculados da planilha. Os rascunhos do colega (títulos “8 CCM1” e “9 CCM2” do memorial original) **ficaram intocados** — o arquivo original `T3-Memorial de Calculo.docx` não foi alterado e as 539 primeiras partes do `_REV_CCM4.docx` são idênticas às do original; se quiser substituí-los, basta remover as seções 8 e 9 e renumerar. Backups da 4ª rodada: `*_v4_BACKUP`. **Nenhum arquivo CAD foi alterado** (o DWG foi lido apenas por cópia convertida, para os rótulos de potência e a geometria).

| CCM | Quadro / processos | Motores + resist. | Instalada [kW] | Demanda operacional S [kVA] / FP | I_alim [A] | Disjuntor geral | Alimentador / barramento | Partida simultânea (rearme escalonado) |
|---|---|---|---|---|---|---|---|---|
| CCM1 | QDGM1; P25A/B (resistências) | 2 | 200,0 | 100,0 / 1,00 | 151,9 | ACW160H-FMU160-3 (Ir 155 A) | 70 mm² / 20 x 3 mm | 2,2 % |
| CCM2 | QDGM1; P8A–D, P9A–D | 8 | 150,0 | 50,3 / 0,82 | 105,1 | ACW160H-FMU125-3 (Ir 110 A) | 50 mm² / 15 x 2 mm | 5,3 % |
| CCM3 | QDGM1; P1A–C | 9 | 19,8 | 7,1 / 0,71 | 17,5 | ACW100H-FMU20-3 (Ir 20 A) | 6 mm² / 12 x 2 mm | 1,5 % |
| CCM6 | QDGM2; P17A/B–P24 | 16 | 435,6 | 385,5 / 0,95 | 716,7 | ACW800U-ETM800-3 (Ir 720 A) | 800 mm² / 2 × 30 x 5 mm por fase | 21,6 % |

### Métodos de partida e componentes especiais (decisões A VALIDAR)

- **Reajuste pelas potências do usuário (`T3/qdgm_ccm_atualizado.xlsx`/`.pdf`, 6ª passagem):** conferi as potências de todos os processos contra a matriz do usuário. Coincidem P1 (3×2 cv), P2–P7, P8 (9,5 cv), P9 (33 cv), P10–P13, P15, P16 (3×7,5 cv), P18 (6 cv), P19 (4 cv), P20 (20 kW), P21 (30 cv + 45 kW), P22 (50 cv + 60 kW), P23 (60 cv + 70 kW), P24 (30 cv) e P25 (2 × 100 kW). **Única mudança: P14 = 3,5 cv** (eu havia lido '5,3CV' no DWG; os três rótulos do DWG original dizem '5,3CV', mas adotei o valor do usuário). Efeito: motor do P14 de 5,5 kW → 3 kW pelo critério técnico, elevado a **3,7 kW por ajuste de projeto** (o de 3 kW fica no limite: Cp 6,3 × 3·C = 6,27 kgfm, queda admissível 0,7 %, cabo de 400 mm² para 8,9 A); totais e alimentador do CCM5 recalculados (instalada 378,5 kW; I_alim 368,7 A; mesmo ACW400H-ETS400-3, Ir 370 A). Os outros cinco CCMs não mudaram.
- **P17 — ENCERRADO (decisão do usuário): 28 + 9 + 2,5 cv por célula.** A matriz `qdgm_ccm_atualizado.xlsx` listava 23 cv como leitura do CAD, mas o DWG original (rótulos '28CV 9CV 2,5CV' do P17) e o enunciado concordam em 28 cv; os 23 cv pertencem ao P4 e ao P13. O usuário confirmou 28 cv: P17A = P17B = 39,5 cv (A titular, B reserva: 79 cv físicos instalados, não simultâneos). Nada a recalcular — o `cfg.py` já usava 28 cv. Totais físicos de referência do usuário: CCM6 259 cv + 195 kW; QDGM2 577,5 cv + 195 kW; geral 903,5 cv + 395 kW.
- **P9 (CCM2) — Y-Δ com motor de 30 kW:** o enunciado fala em torque de partida de 13/33 do nominal; adotei k = 13/33 = 0,39 (o motor de 30 kW sai do critério térmico; k só entra na checagem Cp/3 ≥ k·C). Se o professor quis 1/3, a leitura se troca em `MET` da planilha de inventário (col. N). A VALIDAR. **Dupla tensão 380/660 V assumida** (único modo de ligar em Y-Δ com 380 V na linha); a disponibilidade da versão 380/660 V no catálogo W22 deve ser confirmada.
- **P17-M3 (CCM6) — Y-Δ 30 kW, torque inicial de 9 cv:** k = 9/28; dupla tensão 380/660 V assumida; temporização RTW17-A para os motores de 9 e 2,5 cv (4 s e 5 s) e RTW17-G para a comutação.
- **P21 (CCM6) — série-paralela:** o torque inicial de 7,5 cv = 1/4 do nominal coincide com o conjugado da ligação série (PIE 08 p.60; PIE 10 pp.5–10). Motor de **quádrupla tensão (220/380/440/760 V, 9 terminais)**: A VALIDAR a disponibilidade no catálogo W22 (a pasta não traz a folha de dados dessa ligação).
- **P22 (CCM6) — inversor de frequência:** carga de 50 cv a 1400 rpm com correias 3:1 e η = 90 %. Li 3:1 como redutora (motor mais rápido que a carga: 600–4200 rpm, 2 polos, 70 Hz) → motor de 45 kW; inversor **CFW700D88P0T4DBN1** (derating de altitude 1 %/100 m acima de 1000 m), fusíveis aR FNH00-125K-A, sem relé térmico. **A VALIDAR com o professor:** relação 3:1 (leitura redutora × multiplicadora) e a potência (a ‘dica’ do enunciado cita 30 cv; a planta e o texto do processo indicam 50 cv).
- **P23 (CCM6) — compensadora:** torque inicial 40 % da carga → TAP mínimo 0,42 → TAP padrão 65 %; contatores pelo pior caso dos taps de 65/80 % (K2 = 0,64·IL; K3 = 0,23·IL); relé de classe 20 (RWM420E); autotransformador fica a definir com o fabricante.
- **P24 (CCM6) — compressor intermitente:** ciclo 10 min carga / 5 min repouso; P_eq com repouso valendo 1/3 (autoventilado, Guia WEG p.43) → 22 kW em vez de 30 kW; relé ajustado na I_eq e curva de disparo × 0,25 (PIE 06 p.21), classe 30.
- **Cargas resistivas (P20, P21–P23 térmicas, P25 do CCM1):** contator em categoria **AC-1** (coluna nova `D_CONTATOR` col. H), fusível gG e relé de sobrecarga com termostato NF em série; ΔV sem fator de serviço; fora da seleção do ‘maior motor’ do alimentador.
- **Nos métodos de tensão reduzida (Y-Δ, série-paralela, compensadora)** o professor risca o critério In,f ≤ k·Ip,m (PIE 09 p.52); K1–K3(–K4) são aumentados até o fusível máximo do contator cobrir o menor fusível comercial (In,f·Ta ≥ 1,2·In); t_rb corrigido por (Un/Ur)².
- **Alimentador do CCM6:** I_alim = 716,7 A → disjuntor **ACW800U-ETM800-3** (adicionado a `D_DISJUNTOR`; Icu 100 kA) e seção equivalente de **800 mm²** — acima de 240 mm², isto é, **cabos em paralelo** (barramento ‘2 × 30×5 mm por fase’). Comprimento e agrupamento do CCM6 são limites superiores a partir do DWG (parede x = 197,77); a ΔV a montante do QDGM2 segue pendente.
- **Altura da sala (CCM1/CCM3):** H = 7,0 m assumido (rótulo do DWG no CCM2; os demais sem cota) — afeta só o limite de percurso do cabo.
- **Dados de catálogo acrescentados nesta rodada:** MSW até 160 A, fusíveis NH 200/224/250 A, ACW400H/630H-ETS e ACW800U-ETM800, relés RWM420E (K1 > 105 A), inversores CFW700 (aba `D_INVERSOR`), coluna AC-1 dos contatores CWM (catálogo CWM pp.4–6).

### Testes desta rodada

- **Verificador independente** (`verify.py`, reescrito para os seis CCMs e todos os métodos): CCM1–CCM6 com **0 divergências** contra a planilha recalculada (motores, componentes, cabos, células, totais, disjuntor geral, barramento e alimentador).
- Planilha avaliada com o motor `formulas`: **nenhum erro de fórmula** (#REF!, #VALUE!, #NUM!…) nem flag ‘REVER/NÃO/INVIÁVEL’ nas abas dos seis CCMs; DOCX relido com python-docx: sem marcadores vazios, sem ‘nan/None’, 539 elementos originais idênticos.
- **Regressão CCM4/CCM5 contra a 4ª rodada** (`ccm_r4.xlsx.json` × final): **0 diferenças numéricas** em todas as abas dos dois CCMs (fora as matrizes auxiliares `AUX_FUSIVEL`, cujo layout de colunas cresceu com os novos candidatos); só rótulos de texto foram generalizados.
- Cenários de entrada (altitude, T, FC, FS, Icc, N_ALIM, tensão) foram rodados na 4ª rodada para CCM4/CCM5; **para os CCM1/2/3/6 os cenários não foram repetidos** (cada recálculo leva ≈ 2,5 min com seis CCMs) — a planilha reage por fórmulas, mas só o caso-base está validado pelo verificador.

## 0A. 4ª RODADA — REVISÃO DO CCM4 E INCLUSÃO DO CCM5

Pedido: *revisar e fazer o CCM5 também nos docs e planilhas já iniciados*. O CCM5 (QDGM2, Recapagem: P10A–C, P11A–B, P12A–C, P13A–B, P14A–C, P15A–C, P16A–B — 18 quadros, 22 motores) entrou **na mesma planilha** (abas de prefixo `C5_`, mesma estrutura do CCM4) e **no mesmo memorial** (nova seção 12). Backups da rodada anterior: `*_v3_BACKUP`. Nenhum CAD foi alterado (DWG lido em cópia temporária, já apagada). **Onde os números das seções 0 a 7 abaixo (rodadas 2–3) divergirem desta seção, vale esta.**

### Revisão do CCM4 — o que mudou

- **Queda unitária no fator de potência 0,30 (partida).** Na 3ª rodada eu extrapolava linearmente a Tabela 12 do Prysmian (FP 0,8 → 0,95 → 0,30), o que superestimava a queda em 6–37 % e *crescia* nas seções grandes. Corrigido: como ΔV = √3·I·L·(R·cos φ + X·sen φ) (PIE 05 p.23), as duas colunas tabeladas determinam R′ e X′ de cada seção (`D_CABO` col. H). Efeito: alimentadores de **P6/P7 de 35 para 25 mm²**; P4 continua em 25 mm², agora definido pelo orçamento de queda de tensão.
- **Orçamento de 7 % virou critério de seleção** do alimentador de cada célula (`7_CELULAS` col. AK–AL), em vez de só conferência; e a queda de 4 % virou critério de seleção do cabo do motor (`6_CONDUTORES` col. AA–AB). No CCM4 nenhum cabo de motor mudou.
- **Texto errado em `4_ACIONAMENTOS` col. P:** a justificativa dizia sempre “Cp/3 < C” mesmo quando Cp/3 ≥ C (9 dos 11 tipos). Agora o sinal é calculado.
- **Especificação do motor** citava “220/380 V” fixo; agora usa a tensão do modelo (motores ≥ 225S/M são 220/380/440 V).
- **Motores, seccionadoras, contatores, relés, fusíveis, cabos de motor, totais e alimentador geral do CCM4: inalterados** (regressão célula a célula contra a 3ª rodada + verificador independente: 0 divergências).

### CCM5 — decisões e resultados

**Potências:** o texto do enunciado não as traz; lidas dos rótulos do DWG original (camada `_ELT-MAQUINAS-TEXTO`), um rótulo de potência junto a cada número de processo. A planta não distingue A/B/C.

**Critério novo — conjugado de partida das prensas (P10–P15):** enunciado p.4 (“conjugado de partida mínimo requerido de 3 vezes o nominal”) = PIE 08 pp.34–35 (prensas: 3 × o nominal). Motor = menor W22 que atende potência e torque (FC 0,934, sem FS) **e** Cp de catálogo ≥ 3·C. Como o conjugado cai com o quadrado da tensão (PIE 08 pp.22 e 42), cada célula recebe um limite próprio de queda na partida, mín(10 %; 1 − √(3C/Cp)), e o alimentador é dimensionado para respeitá-lo. Só a partida direta atende com folga (Y-Δ: Cp/3; compensadora: 0,64·Cp ou 0,42·Cp — a única que passaria numericamente é a compensadora a 80 % no P11, com margem de ≈6 %, não adotada).

| Proc. | cv / rpm / tpm | C carga → 3·C [kgfm] | Motor só térmico | **Motor adotado** | Cp [kgfm] | ΔV máx. partida | In / Ip,m [A] | K1 / relé (classe) / fusível | Cabo motor | Disjuntor e alimentador da célula | ΔV partida (limite) | Icc mín. |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P10 | 28 / 3600 / 7 s | 5,57 → 16,71 | 30 kW | **30 kW (40 cv), 2p, 200M** | 19,7 | 7,9 % | 56,5 / 418 | CWM65 / RWM112E-3-A4U112 (cl. 20) / FNH00-125U | 10 mm² | ACW100H-FMU80-3; 35 mm² | 7,71 % (7,92 %) | 6,8 kA |
| P11 | 20 / 3600 / 7 s | 3,98 → 11,93 | 18,5 kW | **30 kW (40 cv), 2p, 200M** | 19,7 | 22,2 % | 56,5 / 418 | CWM65 / RWM112E-3-A4U112 (cl. 20) / FNH00-125U | 10 mm² | ACW100H-FMU80-3; 25 mm² | 9,02 % (10,00 %) | 6,0 kA |
| P12 | 18 / 1200 / 5 s | 10,74 → 32,22 | 15 kW | **18,5 kW (25 cv), 6p, 180L** | 38,2 | 8,2 % | 35,4 / 301 | CWM40 / RWM40E-3-A4U040 (cl. 10) / FNH00-80U | 6 mm² | MDWH-C63-3; 16 mm² | 7,27 % (8,22 %) | 5,7 kA |
| P13 | 23 / 900 / 5 s | 18,30 → 54,89 | 18,5 kW | **37 kW (50 cv), 8p, 250S/M** | 81,4 | 17,9 % | 73,9 / 510 | CWM95 / RWM112E-3-A4U112 (cl. 10) / FNH00-125U | 16 mm² | ACW100H-FMU100-3; 35 mm² | 9,81 % (10,00 %) | 6,8 kA |
| P14 | 3,5 / 1200 / 3 s | 2,09 → 6,27 | 3 kW | **3,7 kW (5 cv), 6p, 132S** | 7,4 | 7,9 % | 8,8 / 66 | CWM12 / RWM40E-3-A4U025 (cl. 10) / FDW-25S | 4 mm² | MDWH-C16-3; 6 mm² | 2,80 % (7,94 %) | 1,1 kA |
| P15 | 13 / 1200 / 3 s | 7,76 → 23,27 | 11 kW | **15 kW (20 cv), 6p, 160L** | 29,8 | 11,6 % | 30,8 / 210 | CWM40 / RWM40E-3-A4U040 (cl. 10) / FDW-50S | 6 mm² | MDWH-C50-3; 16 mm² | 5,40 % (10,00 %) | 2,8 kA |
| P16 | 7,5 / 1800 / 2 s | 2,98 → 2,98 | 7,5 kW | **7,5 kW (10 cv), 4p, 132S** | 9,5 | — | 14,7 / 120 | CWM18 / RWM40E-3-A4U025 (cl. 10) / FDW-35S | 4 mm² | MDWH-C50-3; 16 mm² | 9,85 % (10,00 %) | 6,8 kA |

**Totais do CCM5:** instalada 380,6 kW (22 motores); máxima simultânea pela lógica 178,9 kW (11 titulares); P = 118,5 kW, Q = 78,3 kvar, **S = 142,0 kVA**, FP 0,834; **Ib = 368,7 A** → **ACW400H-ETS400-3** (Ir = 370 A), cabo **3 × 240 mm²** (N = 9; conservador — o QDGM2 tem poucas saídas), barra 20 x 10 mm; ΔV QDGM2→CCM5 = 2,51 % no maior percurso possível.

- **Ajustes de projeto (3), registrados em `C5_2_INVENTARIO` col. O–P:** **P11** → 30 kW: com tpm = 7 s, os motores de 18,5 kW (t_rb quente 11 s) e 22 kW (9 s) não admitem classe de relé entre 1,25·tpm e t_rb (classe 10 ≈ 7,1 s; classe 20 ≈ 11,4 s). **P13** → 37 kW: o de 30 kW só manteria 3·C com queda ≤ 6,4 %, e a própria partida dele já causa 6,8 % no barramento. **P14** (3,5 cv, valor da planilha `qdgm_ccm_atualizado.xlsx`; o rótulo do DWG diz '5,3CV') → 3,7 kW: o de 3 kW atende 3·C por só 0,5 % (queda admissível 0,7 % < 0,64 % do barramento ⇒ cabo de 400 mm² para 8,9 A); o de 3,7 kW admite 7,9 % e fecha com 6 mm².
- **Sem temporizadores no CCM5:** P10–P15 têm um motor por célula e os três motores do P16 têm o mesmo tpm (2 s).
- **Geometria:** CCM5 “junto à parede divisória com a área de Caldeiras” (enunciado p.2) → parede em x = 241,14, y = 108,05…123,97 (15,92 m = cota 15,917). Limite de percurso por processo = maior caminho ortogonal de qualquer ponto da parede ao canto mais distante das máquinas + 2 × 7,0 m: de 35,9 a 56,6 m.
- **Dados de catálogo acrescentados:** disjuntores ACW400H-ETS400 e ACW630H-ETS630 (ACW p.6 e p.10).

### Ressalvas específicas do CCM5

- **Margem de curto-circuito pequena:** P10, P13 e P16 exigem Icc ≥ 6,8 kA no CCM5 para respeitar o limite de queda na partida — quase os 7 kA presumidos. Com Icc = 6 kA (cenário testado) os alimentadores de P10, P13 e P16 precisam subir bastante (ver cenários). É o ponto mais sensível ao T4.
- **Leitura do “3 vezes o nominal”:** adotei 3 × o conjugado nominal da *carga* (716·cv/n). Se o professor quiser motor de **categoria D/H**, o catálogo da pasta não tem — e o enunciado impõe W22 IR3 Premium.
- **Critério de tensão é meu (fundamentado, mas não é exemplo de aula):** limite de queda por célula para manter Cp ≥ 3·C. A alternativa `MODO_CP = 2` (Cp·0,81 ≥ 3·C), com os ajustes de projeto zerados, subia P10, P12 e P14 (então 5,3 cv) uma potência e levava o P13 aos mesmos 37 kW (cenário da 4ª rodada; **não repetido** após a correção do P14 para 3,5 cv). Atenção: ligar `MODO_CP = 2` **sem** zerar os ajustes empilha os dois (P11 → 37 kW, P13 → 45 kW) e estoura a tabela de seccionadoras/fusíveis (cenário testado).
- **P14 (3,5 cv) é caso de fronteira:** ajuste de projeto para 3,7 kW (limite de queda 7,9 %, cabo de 6 mm²); o motor de 3 kW fecharia só com cabo de 400 mm².
- **Disjuntores de célula na partida longa:** a corrente de partida fica em 3–5,2 × In do disjuntor por até 7 s; só o disparo magnético foi verificado (curva térmica do MDW não consta na pasta; a do ACW não foi digitalizada).
- **Motores de prensa em carga parcial (46–72 %):** η e cos φ reais menores que os de placa — afeta a correção de FP do QDGM2.
- **Rearme escalonado é requisito** (todas as células juntas ≈ 38 % de afundamento).

### Testes desta rodada

- Verificador independente (`verify.py`, reescrito para os dois CCMs: motores com critério de Cp e ajustes, componentes, cabos com critério de ΔV, disjuntor/seção/afundamento/limite de cada célula, totais, disjuntor geral, Ir, seção e ΔV do alimentador): **CCM4 0 divergências; CCM5 0 divergências**.
- Regressão do CCM4 contra a 3ª rodada, célula a célula: diferenças apenas nas colunas afetadas pelas correções acima.
- 15 cenários de entrada sobre a planilha combinada (altitude, temperatura, FC, FS, MODO_CP, Icc 6/10 kA, N_ALIM, 440 V, P5 = 7,5 cv, retirar cada ajuste de projeto, P10 com k = 1, comprimento medido): ver resultado no final do arquivo.
- Resultado dos cenários: sem erros de fórmula, exceto `MODO_CP = 2` com os ajustes ativos (motores de 45 kW fora da tabela de seccionadoras até 75 A — agora sinalizado como REVER). Motores do CCM5 não mudam com altitude 2000 m, 40/50 °C, FC da fonte primária ou FS: quem manda neles é o conjugado de partida. **Icc = 6 kA:** alimentadores de P10 e P13 sobem de 35 para 70 mm² e os do P16 de 16 para 25 mm² (todas as células continuam atendendo). **Icc = 10 kA:** P10 cai para 25 mm². **50 °C:** alimentador geral do CCM5 vai a 300 mm² e o do CCM4 a 120 mm². Retirar o ajuste do P13 → célula INVIÁVEL e Cp na tensão real < 3·C (flags aparecem); retirar o do P11 → relé REVER (flags aparecem). Comprimento medido de 20 m no P13A → afundamento cai de 9,8 para 8,7 %.
- Memorial: os 539 elementos originais do DOCX continuam idênticos; seção 11 regenerada e seção 12 nova (10 tabelas, 2 equações, 2 figuras). **Não foi aberto no Word/Excel.**

## 0. 3ª RODADA — O QUE FOI FECHADO POR INFERÊNCIA (aba `15_INFERENCIAS`)

Pergunta do usuário: *não dá para inferir as informações que faltam interpretando as aulas e catálogos?* **Dá, em quase tudo.** Cada item abaixo deixou de ser “pendente” e passou a **INFERIDO** (limite superior, com fonte e página); a coluna de comprimento das abas 6/7/8 continua aceitando o valor medido no CAD e o substitui.

| Item | Como foi inferido | Fonte (arquivo + página) | Resultado |
|---|---|---|---|
| **Escala e dimensões da planta** | Planta em **metros**: cota 30,917 (`_COTAS`) = distância entre as paredes da Raspa (x 204,00 → 234,91); cota 8,124 = profundidade (y 87,14 → 95,26); rótulo “RASPA - 7,0 m”; edificação 53,6 × 47,2 m. 9 máquinas do CCM4 com posição e tamanho (≤ 2,2 × 3,2 m) lidas do DWG original (cópia; CAD intacto). | `05 - Projeto Industrial…/02 - Plantas e DWG/PROJETO INDUSTRIAL - RECAPADORA DE PNEUS - 2026-2.dwg` (camadas `_COTAS`, `_ARQ`, `_ELT-MÁQUINAS`) | L_Raspa = W+D+2H = **53,0 m**; L_edificação = **114,8 m** |
| **Onde está o CCM4 e os quadros** | Enunciado manda o CCM4 “dentro da área de Raspa” e “um único quadro de acionamento próximo à célula”. | `PIE Industria RECAPADORA… Dados iniciais.pdf` p.1 e p.2 | Terminais curtos; alimentadores ≤ percurso da Raspa |
| **Queda de tensão dos circuitos terminais** | ΔV no maior percurso possível da Raspa, com I = In·FS (PIE 05 p.15) e Tab. 12 Prysmian | PIE 05 p.15; Prysmian PDF p.61–62 | máx. **3,44 %** ≤ 4 % nos 17 circuitos; L admissível mín. 62 m |
| **Agrupamento (FCA)** | Terminais: N = motores da célula (quadro junto à máquina). Alimentadores das células: 9 saídas do CCM4 na mesma bandeja → **N = 9, FCA 0,72**. QDGM1→CCM4: ≤ 4–5 saídas do QDGM1 → coberto por N = 9. | Prysmian PDF p.57 (Tab. 7 item 4); Dados iniciais p.1–2 | Alimentador do CCM4: **70 → 95 mm²**; alimentadores das células recalculados |
| **Afundamento de tensão na partida (limite)** | **Critério encontrado**: queda nos terminais do dispositivo de partida ≤ **10 %**, FP **0,30**, +3 m/curva (≥ 10 mm²); tolerável >10 % só se não afetar outras cargas. Reforço: W22 Zona B ±10 %; PIE 03 ±10 %; contator só desopera abaixo de 0,75 Un. | **PIE 05 p.17**; W22 p.19 (Fig. 28); PIE 03 p.117 e 120; PIE 08 p.82 | Cada célula atende **partindo uma por vez** (máx. 8,62 %); partida simultânea (19 %) **não** atende → rearme escalonado (requisito). Icc mín. por célula calculado (critério para o T4). |
| **Queda de tensão total (7 %)** | Pior caso empilhado: QDGM1→CCM4 (L_edificação) + CCM4→célula (L_Raspa) + célula→motor (25 m) | Prysmian PDF p.62 | **5,28 %**; folga **1,72 %** para o trecho trafo→QDGBT→QDGM1 (reserva adotada 1,5 %) |
| **Coordenação de sobrecarga dos alimentadores** | IB ≤ IN ≤ IZ e I₂ = 1,45·IN ≤ 1,45·IZ′ (NBR NM 60898) | Prysmian PDF p.63 | OK em 9 alimentadores de célula e no do CCM4 |

**Descoberta importante (erro meu das rodadas anteriores):** o PIE 05 p.17 traz o critério de afundamento de partida (10 % / FP 0,30 / +3 m por curva) e o p.15 manda usar **In × FS** na queda de tensão de circuitos de motor. Eu não tinha aplicado nenhum dos dois. Aplicados: os alimentadores de **P4, P6 e P7 passam a 25 mm²** (antes 10 mm²; na 3ª rodada P6/P7 saíram com 35 mm² por um erro de extrapolação corrigido na 4ª — ver 0A); P2/P3 passam a 16 mm² (agrupamento N = 9). Motores, componentes de manobra/proteção e cabos terminais **não mudaram**.

**O que NÃO dá para inferir com o material da pasta (continua em aberto):** (i) a **impedância real do transformador / Icc real** no CCM4 (T4) — deixei o critério de aceitação: Icc ≥ valor mínimo por célula (aba 7_CELULAS col. AI; maior = P6/P7); (ii) a **queda de tensão do trecho trafo→QDGBT→QDGM1** (T3 geral) — o CCM4 deixa folga ≥ 1,7 %; (iii) a **curva térmica do MDW/MDWH** (não consta no catálogo da pasta; a corrente de partida fica em 3,5–4,7 × In, abaixo do limite magnético de 5 × In); (iv) **Icw/Icm da MSW** contra 7 kA; (v) posição exata do QDGM1 e traçado real (só refinam, não mudam seções).

## 1. ERROS ENCONTRADOS E CORRIGIDOS

- **Diagnóstico errado sobre o DWG.** A 1ª rodada afirmou que o AutoCAD “não abriu o arquivo por falha de licença”. Era timeout curto: com tempo maior o `accoreconsole` abre o DWG. Reli o **DWG original** (cópia convertida para DXF): os 4 rótulos `5CV` do Processo 5 (y = 88,73; x = 211,89 / 214,73 / 217,42 / 220,57), cada um sobre o rótulo `5` de mesmo x, estão lá. P5 = 5 cv **confirmado** (e P2: 12/3/2 cv; P3: 15/2; P4: 23/3; P6/P7: 5/7/17 — idênticos ao enunciado). Texto do memorial e da aba `9_PENDENCIAS` corrigidos.
- **Fator T×H não respondia à temperatura** (só à altitude; usava dois pontos fixos). Agora a aba `D_FATOR_TH` traz as tabelas completas (PIE 08 p.28 e fonte primária WEG) com interpolação bilinear e alarme “FORA DA TABELA”. Testado: 40/45/50 °C e 1000/1200/1500/2000 m.
- **`In(380) = In(220)×0,577` fixo**, independente de `V_LL`. Agora `K380` depende da tensão (0,577/0,5/1,0 ou “VALIDAR”).
- **Constantes embutidas em fórmulas** (0,8·t_rb; taps 0,64 e 0,4225; resolução 0,5 A e 5 A; folga 1,1 do temporizador; 10 s do contator; limites de cos φ 0,8/0,95; k = 0,8 do magnético; 400 A/10×In do FMU). Varredura de 3.000 fórmulas: restaram só constantes estruturais (0, 1, 2, 1000, 100, 120·f/p, tolerância 1E-9, regras PE 16/35). Todo o resto virou parâmetro (`1_FONTES_PREMISSAS`) ou dado de catálogo (`D_DISJUNTOR` coluna Im).
- **Lista de disjuntores ACW misturava versões H e V** fora de ordem (bug que só aparecia com correntes maiores; ex.: ALT = 2000 m escolhia `ACW100V`). Filtrado para a versão H.
- **Análise de Y-Δ generalizava “W22 é 220/380 V”.** Agora a tensão é lida **do modelo selecionado** (coluna `D_W22!Y`; catálogo W22 p.21 e p.24): todos os 11 modelos são carcaça ≤ 200L → 220/380 V, 6 terminais. A razão de torque Cp/3 ÷ C é mostrada (em 9 dos 11 tipos de motor o Y-Δ passaria no torque de rotor bloqueado, mas com razão Cp/3 ÷ C de apenas 1,00 a 1,46 — P4-M2: 1,003 —, sem margem de aceleração para carga de 100 %; P2-M3 e P5 reprovam também no torque).
- **Partida direta estava tratada como decisão fechada.** Passou a **SELEÇÃO PRELIMINAR CONDICIONADA À VERIFICAÇÃO DE AFUNDAMENTO DE TENSÃO** (nova aba `13_VERIF_PARTIDA`: ≈0,8–5,6 % por célula; ≈19 % se todas as células religarem juntas, com Icc = 7 kA).
- **Terminologia de intertravamento imprecisa** (“relés de sobrecarga intertravados”). Corrigido: contato auxiliar NF 95-96 do relé em série no comando → abre os contatores de todos os motores da célula = intertravamento **elétrico de comando**; temporizadores só retardam a energização; o “intertravamento mecânico” do enunciado é a partida/parada conjunta (não é BLIM/CWI).
- **Números digitados no DOCX** (Cn 10,2 e 4,17 kgfm; “3,7 kW”; “11 kW”) → agora vêm do catálogo da planilha. Conferência: 1.630 tokens numéricos da seção 11; só ficam sem par na planilha tensões (380/660, 440, 415) e anos.
- **`MODO_FS` exposto no memorial/pendências** sem dizer qual método vale. Agora o memorial declara um único método (Apêndice D); a chave permanece na planilha apenas como sensibilidade, rotulada “não faz parte do método entregue”.
- **Faltava a verificação cv do motor ≤ cv do contator K1 (AC-3, 380 V).** Incluída (`5_PROT_MANOBRA` AQ:AR): 17/17 OK.
- **Alimentador de 70 mm² apresentado sem dizer que depende do agrupamento.** Nova aba `14_ALIMENTADOR_CCM4` (recálculo do zero + sensibilidade): 70 mm² só vale para N ≤ 2 circuitos na bandeja; N ≥ 3 → 95 mm².
- **(3ª rodada) Critério de partida e FS na queda de tensão não aplicados.** PIE 05 p.17 (≤ 10 % nos terminais do dispositivo de partida; FP 0,30; +3 m/curva) e p.15 (corrente do motor × FS na ΔV). Corrigido (7_CELULAS col. AD–AI; 6_CONDUTORES col. X): alimentadores de P4/P6/P7 maiores.
- **Aba de pendências incompleta:** acrescentados (i) coordenação da seccionadora MSW com 7 kA (Icw da MSW12/16/20 = 300 A; impulso 5 kA — catálogo MSW p.6), (ii) tad do fusível conservador (seção mínima 4 mm² nos circuitos com fusível D).

## 2. DECISÕES CONFIRMADAS

- **Seleção por potência E torque, sem FS** (ver Apêndice D): resultado idêntico ao da 1ª rodada nos 17 motores (verificação independente em Python: 0 divergências).
- **FC = 0,934** (PIE 08 p.28) — ver Apêndice B (divergência).
- **P4-M2 (23 cv → 18,5 kW)**: relé classe 20 (tar = 11,7 s; classe 10 daria 7,3 s ≈ tpm = 7 s) e fusível NH FNH00-80U (o FDW-63S seguraria só 5,7 s < 8,75 s).
- **Cabos terminais 4 mm² (6 mm² para P3-M2, P4-M2, P6-M3)**; PE conforme PIE 05 p.49.
- **Cargas:** instalada 126,9 kW; máxima simultânea pela lógica 90,9 kW (12 titulares); reservas 36,0 kW; demanda 98,7 kVA; FP 0,808; Ib = 196,5 A; ACW250H-ATU200 (Ir = 200 A); Icu 85 kA ≥ 7 kA. Recalculado do zero em código independente: todos iguais.
- **P5 = 5 cv** (agora confirmado no DWG original).

## 3. DECISÕES ALTERADAS

- Partida direta: da 2ª rodada (“seleção preliminar”) para **verificada pelo critério PIE 05 p.17 com Icc = 7 kA, uma célula por vez** (3ª rodada); confirmação final com a impedância real no T4.
- Alimentador QDGM1 → CCM4: 70 mm² → **95 mm²** (N = 9, FCA 0,72); alimentadores das células: P2/P3 16 mm², P4 25 mm², P5A–D 6 mm², P6/P7 25 mm² (agrupamento N = 9 + afundamento de partida + orçamento de 7 %); PE ajustado.
- Queda de tensão: de “PENDENTE (comprimento)” para **calculada no maior percurso possível** (L_Raspa, L_edificação), com folga para o trecho a montante.
- Status do P5: de “a conferir” para **confirmado**.
- FS: de “dois modos” para **um método único documentado** (sem FS).
- Texto do memorial: nova seção 11.6 (método de partida, linha temporal, intertravamento), 11.5 reescrita (origem das duas leituras de FC), 11.13 (três grandezas de potência), 11.14 (definitividade do alimentador).
- Motores, seccionadoras, contatores, relés, fusíveis e cabos terminais: **nenhum mudou** (verificação independente 0 divergências); mudaram apenas alimentadores (agrupamento e afundamento).

## 4. DECISÕES AINDA PROVISÓRIAS

- **Partida direta de todos os motores** — verificada (PIE 05 p.17) com Icc = 7 kA do enunciado, uma célula por vez; confirmação final com Icc real (T4). Alternativa verificada quanto ao conjugado: compensadora (taps 80 % e 65 % atendem os 11 tipos; P5 a 65 % com razão 1,01).
- **FC = 0,934** — correto para a tabela do professor; a fonte primária daria 0,938 e mudaria só P6-M2/P7-M2 (5,5 kW com folga de +0,14 %).
- **Sem FS**: se o professor usar o exemplo do PIE 09 p.38 como regra, 12 dos 17 motores descem uma potência (simulação em `MODO_FS = 1`; carga instalada cairia para 114,9 kW).
- **Ta do fusível = 0,85** (reta do catálogo, p.29, vetorial) × 0,9 dos slides — pode trocar 1 fusível.
- **tad do fusível em 7 kA** = menor tempo da curva (D 3,8 ms; NH 1 ms) — limite superior; com I²t real, os menores circuitos poderiam ser 2,5 mm².
- **Curvas digitalizadas** (relé RW_E p.5; fusíveis pp.24 e 28): extraídas dos caminhos vetoriais dos PDFs e validadas contra a classe IEC (7,2×Ir: 7,2/11,5/20 s) e contra o exemplo do PIE 08 p.78 (113 A/5 s: 35 e 50 A seguram, 25 A não); incerteza de leitura estimada ≤ ±10 % no tempo.
- **Agrupamento dos cabos** (FCA): INFERIDO — terminais: nº de motores da célula (quadro junto à máquina); alimentadores: N = 9 (limite superior, FCA 0,72). Reavaliar só se > 9 circuitos de potência dividirem a mesma bandeja.
- **Reserva de 1,5 % de queda de tensão** para o trecho trafo→QDGBT→QDGM1 (INFERIDO; o CCM4 deixa ≥ 1,7 %).

## 5. PENDÊNCIAS QUE DEPENDEM DO CAD/T4

- **Icc real no CCM4 (T4):** confirmar Icc ≥ Icc mín. por célula (7_CELULAS col. AI; pior: P6/P7). Se menor → compensadora ou rearme ainda mais escalonado.
- **Queda de tensão do trecho trafo → QDGBT → QDGM1** (T3 geral): o CCM4 deixa folga ≥ 1,7 % dos 7 %.
- **Curva térmica do MDWH** (não consta na pasta) e **coordenação MSW × 7 kA** (Icw/Icm da chave; o exemplo do professor não trata).
- **Refinamento opcional:** comprimentos medidos no CAD (substituem o limite superior) e posição do QDGM1 — não alteram seções.
- Correção do FP (QDMC1) usa P, Q e FP do CCM4 (aba 8_CCM4).

---
## Apêndice A — Item 1: auditoria dos 17 motores (aba `11_AUDITORIA_MOTORES`)

Conta: `P_mec[kW] = cv×0,736`; `C = 716·cv/n`; `P_nm,min = P_mec/FC`; `C_nm,min = C/FC`; FC = 0,934. Catálogo: `WEG - Motores Trifasicos W22 - Catalogo Tecnico.pdf` p.34 (2p), p.35 (4p), p.37 (8p). Linhas usadas conferidas contra a imagem das páginas.

| Motor | cv | rpm | P_mec kW | P_nm,min kW | C_nm,min kgfm | Motor (kW/cv, p, carcaça) | Pág. | Pnom·FC kW (folga) | Cn·FC kgfm (folga) | In380 A | η | cosφ | Ip/In | Cp kgfm | Cmáx kgfm | Margem |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| P2-M1 | 2 | 900 | 1,472 | 1,576 | 1,704 | 2,2 kW / 3 cv, 8p, 132M | 37 | 2,05 (39,6 %) | 2,30 (44,4 %) | 5,38 | 86,5 % | 0,72 | 6,5 | 5,7 | 6,2 | margem confortável |
| P2-M2 | 3 | 900 | 2,208 | 2,364 | 2,555 | 3 kW / 4 cv, 8p, 132M | 37 | 2,80 (26,9 %) | 3,16 (32,3 %) | 7,33 | 86,6 % | 0,72 | 6,8 | 8,8 | 9,1 | margem confortável |
| P2-M3 | 12 | 900 | 8,832 | 9,456 | 10,221 | 11 kW / 15 cv, 8p, 180L | 37 | 10,27 (16,3 %) | 11,39 (19,4 %) | 23,43 | 91,3 % | 0,78 | 7,0 | 25,6 | 32,9 | margem confortável |
| P3-M1 | 2 | 1800 | 1,472 | 1,576 | 0,852 | 2,2 kW / 3 cv, 4p, L90L | 35 | 2,05 (39,6 %) | 1,14 (43,2 %) | 4,70 | 87,5 % | 0,81 | 7,4 | 3,4 | 3,8 | margem confortável |
| P3-M2 | 15 | 1800 | 11,040 | 11,820 | 6,388 | 15 kW / 20 cv, 4p, 160M | 35 | 14,01 (26,9 %) | 7,69 (28,8 %) | 29,66 | 93,4 % | 0,82 | 7,7 | 24,7 | 28,8 | margem confortável |
| P4-M1 | 3 | 1800 | 2,208 | 2,364 | 1,278 | 3 kW / 4 cv, 4p, 100L | 35 | 2,80 (26,9 %) | 1,58 (32,3 %) | 6,40 | 88,0 % | 0,81 | 6,7 | 5,2 | 5,4 | margem confortável |
| P4-M2 | 23 | 1800 | 16,928 | 18,124 | 9,795 | 18,5 kW / 25 cv, 4p, 160L | 35 | 17,28 (2,1 %) | 9,53 (4,1 %) | 36,81 | 93,8 % | 0,81 | 7,3 | 27,5 | 32,6 | margem apertada (< 5 %) |
| P5A-M1 | 5 | 900 | 3,680 | 3,940 | 4,259 | 4,5 kW / 6 cv, 8p, 160M | 37 | 4,20 (14,2 %) | 4,65 (16,9 %) | 11,19 | 88,0 % | 0,69 | 5,1 | 9,5 | 12,0 | margem confortável |
| P5B-M1 | 5 | 900 | 3,680 | 3,940 | 4,259 | 4,5 kW / 6 cv, 8p, 160M | 37 | 4,20 (14,2 %) | 4,65 (16,9 %) | 11,19 | 88,0 % | 0,69 | 5,1 | 9,5 | 12,0 | margem confortável |
| P5C-M1 | 5 | 900 | 3,680 | 3,940 | 4,259 | 4,5 kW / 6 cv, 8p, 160M | 37 | 4,20 (14,2 %) | 4,65 (16,9 %) | 11,19 | 88,0 % | 0,69 | 5,1 | 9,5 | 12,0 | margem confortável |
| P5D-M1 | 5 | 900 | 3,680 | 3,940 | 4,259 | 4,5 kW / 6 cv, 8p, 160M | 37 | 4,20 (14,2 %) | 4,65 (16,9 %) | 11,19 | 88,0 % | 0,69 | 5,1 | 9,5 | 12,0 | margem confortável |
| P6-M1 | 5 | 3600 | 3,680 | 3,940 | 1,065 | 4,5 kW / 6 cv, 2p, 112M | 34 | 4,20 (14,2 %) | 1,18 (18,3 %) | 8,65 | 89,5 % | 0,88 | 7,5 | 3,1 | 3,9 | margem confortável |
| P6-M2 | 7 | 3600 | 5,152 | 5,516 | 1,491 | 7,5 kW / 10 cv, 2p, 132S | 34 | 7,01 (36,0 %) | 1,93 (38,9 %) | 14,31 | 90,6 % | 0,87 | 8,1 | 5,2 | 7,0 | margem confortável |
| P6-M3 | 17 | 3600 | 12,512 | 13,396 | 3,620 | 15 kW / 20 cv, 2p, 160M | 34 | 14,01 (12,0 %) | 3,86 (14,1 %) | 28,27 | 92,2 % | 0,87 | 7,4 | 11,2 | 12,4 | margem confortável |
| P7-M1 | 5 | 3600 | 3,680 | 3,940 | 1,065 | 4,5 kW / 6 cv, 2p, 112M | 34 | 4,20 (14,2 %) | 1,18 (18,3 %) | 8,65 | 89,5 % | 0,88 | 7,5 | 3,1 | 3,9 | margem confortável |
| P7-M2 | 7 | 3600 | 5,152 | 5,516 | 1,491 | 7,5 kW / 10 cv, 2p, 132S | 34 | 7,01 (36,0 %) | 1,93 (38,9 %) | 14,31 | 90,6 % | 0,87 | 8,1 | 5,2 | 7,0 | margem confortável |
| P7-M3 | 17 | 3600 | 12,512 | 13,396 | 3,620 | 15 kW / 20 cv, 2p, 160M | 34 | 14,01 (12,0 %) | 3,86 (14,1 %) | 28,27 | 92,2 % | 0,87 | 7,4 | 11,2 | 12,4 | margem confortável |

**Motor mecânico de 7 cv (P6-M2/P7-M2)** — `P_mec = 7×0,736 = 5,152 kW`; candidato 5,5 kW (112M, Cn = 1,53 kgfm; catálogo p.34):

| Leitura do fator | FC | P_nm,min = 5,152/FC | 5,5 kW × FC | Folga | Resultado |
|---|---|---|---|---|---|
| Coluna 1250 m do PIE 08 (valor lido sem interpolar) | 0,930 | 5,540 kW | 5,115 kW | -0,72 % | 7,5 kW (10 cv) |
| Interpolação 1000–1250 m do PIE 08 (ADOTADO) | 0,934 | 5,516 kW | 5,137 kW | -0,29 % | 7,5 kW (10 cv) |
| Interpolação 1000–1500 m da fonte primária WEG | 0,938 | 5,493 kW | 5,159 kW | 0,14 % | 5,5 kW (7,5 cv) |

Torque: Cn(5,5 kW) = 1,53 kgfm ≥ C_nm,min = 1,49 kgfm em todas as leituras (Cn·FC = 1,43 ≥ C = 1,39); o limitante é a **potência**.


## Apêndice B — Item 2: divergência 0,934 × 0,938

- **0,934** = interpolação linear, na linha de 45 °C, entre as colunas de 1000 m (0,95) e 1250 m (0,93) da tabela do **PIE 08, p.28**: `0,95 + (200/250)·(0,93 − 0,95)`.
- **0,938** = interpolação linear, na linha de 45 °C, entre as colunas de 1000 m (0,95) e 1500 m (0,92) da **fonte primária**: Catálogo W22 Tabela 15 (PDF p.19) = Guia WEG Tabela 8.1 (PDF p.44): `0,95 + (200/500)·(0,92 − 0,95)`.
- **Origem da diferença (verificada, aba `D_FATOR_TH` bloco C):** as colunas de 1250, 1750 (e demais intermediárias) do PIE 08 **não existem** na fonte primária; são a média das duas colunas oficiais **truncada** na 2ª casa — (0,95+0,92)/2 = 0,935 → 0,93; (1,00+0,97)/2 = 0,985 → 0,98; (0,90+0,87)/2 = 0,885 → 0,88 etc. (6/6 conferidos nas linhas 40/45/50 °C).
- **Metodologia do professor:** ele ensina a tabela do slide (PIE 08 p.28); nos exemplos usa células exatas da grade (PIE 09 p.8: 45 °C/1000 m = 0,95; PIE 10 p.77/p.91: 800 m → coluna 1000 m = 0,95; 2000 m/35 °C = 0,95), sem exemplo de interpolação. Para 1200 m a leitura direta do slide é a interpolação 1000–1250 m (0,934) — ou, de modo mais grosseiro, a coluna de 1250 m (0,93). **Ambas** levam a 7,5 kW. Só a interpolação da fonte primária (0,938) levaria a 5,5 kW.
- **Critério academicamente correto para a disciplina:** hierarquia da própria tarefa (aulas > catálogos): **0,934**. A fonte primária fica registrada como verificação cruzada, e o caso é declarado como **fronteira (diferença de 0,1–0,7 % da potência)**.

## Apêndice C — Item 3: método de partida por motor (`método → alternativas descartadas → motivo → aula/página`)

Critérios nas aulas: PIE 08 p.58 (cinco métodos; em MT a escolha é do projetista), p.59 (direta: “acentua a queda de tensão”, “concessionárias limitam em 5 cv” [BT]; Y-Δ: carga ≤ Cp, dupla tensão, −33 % corrente), p.60 (compensadora tap 65 %/80 %; série-paralela: 4 tensões/9 bornes), p.61 (220/380 V só em Y na rede de 380 V); PIE 09 p.5 (direta, sem critério numérico), p.34 (Y-Δ só para duas tensões 380/220 ou 660/380), pp.99–101 (compensadora: Ip·k², Cp·k²); PIE 10 p.13 (soft-starter: rampa; não parte com 100 % do conjugado), p.39+ (inversor: controle de velocidade). **Nenhuma aula fixa limite de potência para direta em MT** → o único critério restante é o afundamento (T4).

| Motor | Ip/In → Ip,m | C carga | Cp (Cp/3) | Y-Δ (modelo 220/380 V, W22 p.21/24) | Compensadora 80 % (Cp·0,64) | Soft / Inversor / Série-paralela | Método |
|---|---|---|---|---|---|---|---|
| P2-M1 | 6,5 → 35 A | 1,6 kgfm | 5,7 (1,9) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,19 | 3,6 ≥ 1,6: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P2-M2 | 6,8 → 50 A | 2,4 kgfm | 8,8 (2,9) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,23 | 5,6 ≥ 2,4: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P2-M3 | 7,0 → 164 A | 9,5 kgfm | 25,6 (8,5) | ✗ tensão (Δ = 220 V) e ✗ torque | 16,4 ≥ 9,5: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P3-M1 | 7,4 → 35 A | 0,8 kgfm | 3,4 (1,1) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,43 | 2,2 ≥ 0,8: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P3-M2 | 7,7 → 228 A | 6,0 kgfm | 24,7 (8,2) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,38 | 15,8 ≥ 6,0: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P4-M1 | 6,7 → 43 A | 1,2 kgfm | 5,2 (1,7) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,46 | 3,4 ≥ 1,2: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P4-M2 | 7,3 → 269 A | 9,1 kgfm | 27,5 (9,2) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,00 | 17,6 ≥ 9,1: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P5A-M1 | 5,1 → 57 A | 4,0 kgfm | 9,5 (3,2) | ✗ tensão (Δ = 220 V) e ✗ torque | 6,1 ≥ 4,0: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** — imposta pelo enunciado (Dados p.3) |
| P6-M1 | 7,5 → 65 A | 1,0 kgfm | 3,1 (1,1) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,06 | 2,0 ≥ 1,0: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P6-M2 | 8,1 → 116 A | 1,4 kgfm | 5,2 (1,7) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,24 | 3,3 ≥ 1,4: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |
| P6-M3 | 7,4 → 209 A | 3,4 kgfm | 11,2 (3,7) | ✗ tensão (Δ = 220 V); torque Cp/3 ÷ C = 1,10 | 7,1 ≥ 3,4: possível | ✗ / ✗ / ✗ | **Direta (verificada, PIE 05 p.17)** |

**Soft-starter:** carga exige 100 % do conjugado de partida (PIE 10 p.13). **Inversor:** sem requisito de velocidade variável. **Série-paralela:** exige motor de 4 tensões/9 bornes (W22 ≤ 200L: 6 terminais). **Versão 380/660 V:** não consta no catálogo da pasta (só como exemplo genérico, W22 p.21 nota 4 e Guia p.19); se existisse, o Y-Δ seria viável no torque de rotor bloqueado para 9 dos 11 casos e reduziria Ip a 1/3 — alteraria a decisão.

Motores maiores: **P2-M3 (11 kW)** Ip,m = 164 A (Cp/3 < C: Y-Δ também reprova no torque); **P3-M2 (15 kW)** 228 A; **P4-M2 (18,5 kW)** 269 A (maior do CCM4; 3,8 % de afundamento isolado); **P6-M3 (15 kW)** 209 A. **Partida direta: verificada pelo critério do PIE 05 p.17 (≤ 10 % nos terminais do dispositivo de partida) com Icc = 7 kA; confirmação final com a impedância real no dimensionamento da alimentação (T4).**


## Apêndice D — Itens 4 e 5: tensão/ligação e fator de serviço

- **Tensão/ligação (modelos efetivamente selecionados):** carcaças 90L…180L (<= 200L) → **220/380 V, 6 terminais** (W22 p.21: “63 a 200L — 220/380 V; 225S/M a 355M/L — 220/380/440 V”; p.24: “Tensão 220/380 V”; FS 1,25 e IPW55 para ≥ 160M — p.17/p.24). Em 380 V a ligação é Y. 380/660 V não aparece na família como padrão nem opcional no catálogo fornecido.
- **FS — o professor usa FS para compensar derating?** Em **um** exemplo: PIE 09 p.37–38 (carga 22 kW; Pnm ≥ 23,16 kW; motor 22 kW/30 cv; “FS_requerido = 1,06 ≤ FS_catálogo = 1,25”), dentro do dimensionamento da estrela-triângulo. Os demais exemplos (PIE 09 p.7–8, p.63–64, p.106; PIE 10 p.82–83) não usam FS. Não é regra declarada. O catálogo (W22 p.19; Guia p.44) define FS como sobrecarga contínua “sob condições especificadas” (40 °C, ≤ 1000 m) e dá Pmax = Pnom·FC, **sem** autorizar acumular. A formulação **por torque** que o enunciado exige (PIE 10 p.82–83: Cnm = Ccarga/(Tr·η·f)) não tem FS.
- **Recomendação única entregue: NÃO usar FS.** O memorial (11.4) declara isso e as três razões; a chave `MODO_FS` fica só como sensibilidade (12 dos 17 motores descem uma potência se o professor insistir no exemplo isolado).

## Apêndice E — Item 6: linhas temporais (aba `12_LINHA_TEMPO`)

Interpretação conferida no texto oficial (Dados iniciais p.1: “acionados para entrar em regime permanente de velocidade e torque simultaneamente … contadores de tempo … tempos de partida distintos”): maior tpm primeiro; atraso = tpm,máx − tpm; regime comum em t = tpm,máx.

| Célula | Linha temporal |
|---|---|
| P2 | t = 0 s → P2-M3; t = 2 s → P2-M2; t = 3 s → P2-M1; t = 5 s → todos em regime |
| P3 | t = 0 s → P3-M2; t = 3 s → P3-M1; t = 5 s → todos em regime |
| P4 | t = 0 s → P4-M2; t = 5 s → P4-M1; t = 7 s → todos em regime |
| P6 e P7 | t = 0 s → P6-M3; t = 2 s → P6-M2; t = 3 s → P6-M1; t = 5 s → todos em regime |
| P5A–D | t = 0 s → motor; t = 2 s → regime (sem temporizador) |

**Terminologia:** relé de sobrecarga (protege) ≠ contato auxiliar NF 95-96 (abre o comando) ≠ contator K1 (manobra) ≠ temporizador RTW17 (retarda a energização) ≠ intertravamento elétrico de comando (desligamento conjunto) ≠ intertravamento mecânico entre contatores (BLIM/CWI; não usado).


## Apêndice F — Item 7: proteção e manobra por componente (arquivo + página)

Arquivos em `04 - Catalogos Tecnicos/WEG/02 - Protecao e Manobra/`. Fusíveis: `WEG - Fusiveis aR e gLgG (NH).pdf` p.4 (Icu: D 50 kA/500 V; NH 120 kA/500 V), p.20 (FNH00), p.26 (FDW), curvas p.24 (NH) e p.28 (D), Ta p.29 (Kalt = 1,0 até 2000 m). Contator: `WEG - Contatores e Reles de Sobrecarga Termico.pdf` p.4 (CWM9–32), p.5 (CWM40–105): AC-3 Ie (Ue ≤ 440 V), cv a 380 V, fusível máx.; tensão de comando V26 = 220 V/60 Hz (nota 2, p.4); altitude ≤ 3000 m sem derating (PIE 08 p.81). Relé: `WEG - Reles de Sobrecarga Eletronico (RW_E).pdf` p.5 (classes 10/20/30 e curvas), p.7 (RWM40E/112E: faixas, fusível máx.), p.9 (−20…+60 °C; até 2000 m). Seccionadora: `WEG - Seccionadores de 12 a 160A (MSW).pdf` p.6–7. Disjuntores: `WEG - Minidisjuntores e Quadros.pdf` p.3 (curva C 5–10×In), p.6–7 (MDWH Icu 10 kA, Ics 7,5 kA); `WEG - Disjuntor em Caixa Moldada ACW.pdf` p.4–6, 8–9, 31. Temporizador: `WEG - Reles Temporizadores.pdf` p.7–9.

| Motor | In A | Seccionadora (MSW; Ie AC-23A) | Contator (AC-3 Ie; cv@380 V ≥ cv motor; Fmáx) | Relé (faixa; Iaj; classe; tar × tpm × t_rb) | Fusível gG (In·Ta; t@Ip,m ≥ 1,25 tpm; Icu) |
|---|---|---|---|---|---|
| P2-M1 | 5,38 | MSW 12 P-3 H (10 A) | CWM9 (9 A; 5,4 cv ≥ 3 cv; Fmáx 25 A) | RWM40E-3-A4U008 (1.6 – 8 A; Iaj 6 A; cl.10; 7,9 s × 2 s × 43 s) | FDW-10S (10 A·0,85 = 8,5 A; 6,6 s; 50 kA) |
| P2-M2 | 7,33 | MSW 12 P-3 H (10 A) | CWM9 (9 A; 5,4 cv ≥ 4 cv; Fmáx 25 A) | RWM40E-3-A4U008 (1.6 – 8 A; Iaj 8 A; cl.10; 7,6 s × 3 s × 33 s) | FDW-16S (16 A·0,85 = 13,6 A; 4,9 s; 50 kA) |
| P2-M3 | 23,43 | MSW 25 P-3 H (25 A) | CWM32 (32 A; 20,0 cv ≥ 15 cv; Fmáx 63 A) | RWM40E-3-A4U025 (5 – 25 A; Iaj 25 A; cl.10; 7,4 s × 5 s × 14 s) | FDW-50S (50 A·0,85 = 42,5 A; 23,3 s; 50 kA) |
| P3-M1 | 4,70 | MSW 12 P-3 H (10 A) | CWM9 (9 A; 5,4 cv ≥ 3 cv; Fmáx 25 A) | RWM40E-3-A4U008 (1.6 – 8 A; Iaj 5 A; cl.10; 7,3 s × 2 s × 11 s) | FDW-10S (10 A·0,85 = 8,5 A; 6,9 s; 50 kA) |
| P3-M2 | 29,66 | MSW 40 P-3 H (32 A) | CWM40 (40 A; 25,0 cv ≥ 20 cv; Fmáx 80 A) | RWM40E-3-A4U040 (8 – 40 A; Iaj 31,5 A; cl.10; 7,2 s × 5 s × 13 s) | FDW-63S (63 A·0,85 = 53,6 A; 11,4 s; 50 kA) |
| P4-M1 | 6,40 | MSW 12 P-3 H (10 A) | CWM9 (9 A; 5,4 cv ≥ 4 cv; Fmáx 25 A) | RWM40E-3-A4U008 (1.6 – 8 A; Iaj 7 A; cl.10; 7,7 s × 2 s × 15 s) | FDW-16S (16 A·0,85 = 13,6 A; 13,6 s; 50 kA) |
| P4-M2 | 36,81 | MSW 63 P-3 H (50 A) | CWM50 (50 A; 34,0 cv ≥ 25 cv; Fmáx 100 A) | RWM112E-3-A4U056 (14 – 56 A; Iaj 39 A; cl.20; 11,7 s × 7 s × 12 s) | FNH00-80U (80 A·0,85 = 68,0 A; 23,3 s; 120 kA) |
| P5A-M1 | 11,19 | MSW 16 P-3 H (13 A) | CWM18 (18 A; 10,0 cv ≥ 6 cv; Fmáx 35 A) | RWM40E-3-A4U025 (5 – 25 A; Iaj 12 A; cl.10; 8,9 s × 2 s × 37 s) | FDW-20S (20 A·0,85 = 17,0 A; 10,3 s; 50 kA) |
| P6-M1 | 8,65 | MSW 12 P-3 H (10 A) | CWM12 (12 A; 7,5 cv ≥ 6 cv; Fmáx 35 A) | RWM40E-3-A4U025 (5 – 25 A; Iaj 9,5 A; cl.10; 7,3 s × 2 s × 22 s) | FDW-20S (20 A·0,85 = 17,0 A; 3,8 s; 50 kA) |
| P6-M2 | 14,31 | MSW 20 P-3 H (16 A) | CWM18 (18 A; 10,0 cv ≥ 10 cv; Fmáx 35 A) | RWM40E-3-A4U025 (5 – 25 A; Iaj 15,5 A; cl.10; 7,1 s × 3 s × 19 s) | FDW-35S (35 A·0,85 = 29,8 A; 10,6 s; 50 kA) |
| P6-M3 | 28,27 | MSW 40 P-3 H (32 A) | CWM32 (32 A; 20,0 cv ≥ 20 cv; Fmáx 63 A) | RWM40E-3-A4U040 (8 – 40 A; Iaj 30 A; cl.10; 7,3 s × 5 s × 14 s) | FDW-50S (50 A·0,85 = 42,5 A; 9,1 s; 50 kA) |

Todos os critérios binários da aba `5_PROT_MANOBRA` estão OK (relé na faixa; trb ≥ tar > tpm com margem 25 %; In,f ≤ Fmáx do K1 e do relé; Icu ≥ 7 kA; Ip,m ≤ 8·Ie; cv do motor ≤ cv do K1).

**Pontos de ressalva (não escondidos):** (i) a seccionadora MSW12/16/20 declara Icw(1 s) = 300 A e impulso suportável 5 kA (MSW p.6) — com 7 kA presumidos a proteção depende da limitação do disjuntor da célula (MDWH, Icu 10 kA / Ics 7,5 kA ≥ 7 kA); o exemplo do professor não trata isso; (ii) relé no topo da faixa em P2-M3 (Iaj = 25 A em 5–25 A) — aceitável, mas é o único; (iii) curva térmica do MDWH inexistente na pasta.

**Disjuntor da célula:** MDWH curva C 3P (P2/P3: C50; P4/P6/P7: C63; P5A–D: C16) — Icu 10 kA, Ics 7,5 kA ≥ 7 kA (Minidisjuntores p.7); instantâneo mínimo 5×In ≥ Σ In + máx(Ip,m − In) (P3: 250 A × 233 A; P4: 315 A × 275 A).


## Apêndice G — Item 8: alimentador geral do CCM4 (aba `14_ALIMENTADOR_CCM4`, recálculo independente igual)

1. **Entram:** P2, P3, P4, P5A, P5B, P6 (12 motores). 2. **Saem:** P5C, P5D, P7 (5 reservas; 36,0 kW). 3. P = 79,72 kW. 4. Q = 58,12 kvar. 5. S = 98,65 kVA. 6. FP = 0,808. 7. I trifásica da demanda = 149,9 A; soma vetorial das In de placa = 186,5 A; **Ib = 1,25·36,81 + (187,33 − 36,81) = 196,5 A** (PIE 10 p.117). 8. FCT = 0,87 (Prysmian Tab. 6); **FCA = 0,72 (N = 9; Tab. 7 item 4) — INFERIDO (limite superior)**. 9. Iz tabelado (95 mm², F trifólio) = 328 A → Iz′ = 205,5 A. 10. **Ib 196,5 ≤ Ir 200 ≤ Iz′ 205,5: OK** (e I₂ = 1,45·Ir ≤ 1,45·Iz′). 11. Curto: S ≥ 4,9 mm² (tad 10 ms; K = 143); instantâneo 10×In = 2000 A (não atua em 419 A de partida). 12. Icu 85 kA ≥ 7 kA. 13. PE = 50 mm² (PIE 05 p.49). 14. ΔV = **2,56 %** no maior percurso possível (L = 114,8 m, QDGM1 em qualquer ponto da edificação).

**Definitividade:** disjuntor e barramento (20×3 mm; 223 A corrigidos) independem do agrupamento. **Cabo:** N = 1–2 → 70 mm²; N = 3–9 → 95 mm² — adotado **95 mm²** (cobre N até 9). Só reavaliar se > 9 circuitos de potência dividirem a bandeja.


## Apêndice H — Itens 9 a 12

- **Item 9 (carga operacional):** conferido no texto oficial: P5 = 2 titulares (A, B) + 2 reservas (C, D) — Dados p.3; P6 sem reservas e P7 = equivalente e reserva do P6 — pp.3–4. Três grandezas separadas na aba `14` e em 11.13: **instalada 126,9 kW** (nominal dos 17), **máxima simultânea pela lógica 90,9 kW** (12 titulares, nominal) e **operacional de dimensionamento** (P = 79,7 kW; S = 98,7 kVA; Ib = 196,5 A).
- **Item 10 (P5):** CONFIRMADO no DWG original (item 1 acima). Se estivesse errado: troca motor (8p), In, Ip,m, contator, relé, fusível, cabo e Ib; sensibilidade 3/4/5/6/7,5/10 cv em `11_AUDITORIA_MOTORES` bloco C (ex.: 7,5 cv → 7,5 kW, Ib do CCM 209,9 A → ACW250-ATU250).
- **Item 11 (fórmulas):** varredura de ~3.000 fórmulas (item 1 acima); sem referências quebradas, sem circulares (o motor de cálculo teria falhado), unidades: kW↔cv só via `KW_CV`; η em % → decimal (/100) uma vez; √3 só onde há S→I (aba 14); tensão linha = 380 V. **12 cenários testados** (ALT 1000/1500/2000; T 40/50; FC_OPCAO 2; MODO_FS 1; P5 = 7,5 cv; tpm P4-M2 = 10 s → relé “REVER” e flag NÃO, como deve; N_ALIM = 3 → 95 mm²; Icc 10 kA; V_LL 440): todos respondem coerentemente, sem erros. Limitação: a tabela T×H só vale para 40–50 °C e 1000–2000 m (alarme na aba).
- **Item 12 (DOCX × planilha):** a seção 11 é gerada a partir dos valores recalculados da planilha (tabelas e texto); 1.630 tokens numéricos conferidos (apenas tensões e anos sem par). Equações são texto OMML sem números calculados.

## 6. FONTES/PÁGINAS MAIS IMPORTANTES

- Dados iniciais (PDF): p.1 (condições, quadro único, torque equivalente, temporização), p.2 (CCM4), p.3 (processos 2–6; Icc 7 kA), p.4 (processo 7), p.6 (Prysmian).
- PIE 08: p.17–21 (torque/potência), p.26–28 (FS, T×H), p.36/48 (acoplamento), p.58–61 (métodos de partida), p.76–82 (fusível, contator), p.100–104 (relé).
- PIE 09: p.5, 34 (métodos), p.6–23 (exemplo direta: contator, relé, fusível, curto), p.37–38 (FS no exemplo), p.99–101 (compensadora). PIE 10: p.13, 19 (soft), p.82–83 (torque com derating), p.117 (alimentador). PIE 03 p.24 (demanda). PIE 05 p.47/49 (K; PE), p.62 (barras).
- WEG W22: p.17, 19 (Tab.15), 21, 24, 34–37. Guia WEG p.19, 44. Prysmian (PDF): p.56 (Tab.5), p.57 (Tab.6/7), p.61 (Tab.12), p.62 (limites ΔV), p.65 (Tab.13).
- Catálogos de proteção: ver Apêndice F.

## 7. “Eu entregaria estes CCMs ao professor hoje?” — **SIM COM RESSALVAS**

**Por que sim (continua valendo na 3ª rodada):** a metodologia é a da disciplina, cada decisão tem aula/página, os 17 motores foram reconferidos contra a imagem do catálogo, um modelo independente reproduz motores, componentes, cabos, totais e alimentador (0 divergências), e 12 cenários de entrada respondem corretamente. O que a auditoria derrubou foram premissas implícitas, não números.

**Ressalvas que o professor pode explorar (e que eu não escondo):**

- **Partida direta depende de Icc real e de rearme escalonado.** Verificada pelo critério PIE 05 p.17 com os 7 kA do enunciado (cada célula ≤ 10 %, uma por vez; religamento simultâneo ≈ 19 % não atende → requisito de rearme escalonado); o T4 precisa confirmar Icc ≥ valor mínimo por célula.
- **Três escolhas de método podem divergir do gabarito:** sem FS (12 de 17 motores mudariam), FC = 0,934 (7 cv: 5,5 × 7,5 kW) e Ta = 0,85 (1 fusível). Estão documentadas e reversíveis na planilha, mas só o professor pode arbitrar.
- **Cabos e queda de tensão: fechados por limite superior, não por medição.** Comprimentos (L_Raspa 53 m; L_edificação 115 m) e agrupamento (N = 9) são inferências conservadoras com fonte; o professor pode preferir comprimentos reais da planta motriz, que substituem o limite sem alterar a lógica. Resta a queda do trecho a montante do QDGM1 (T3 geral; folga ≥ 1,7 %).
- **Curvas de relé e fusível foram digitalizadas** (boa validação, mas não são dado tabelado do fabricante); tad do fusível a 7 kA é conservador (4 mm² mínimos).
- **MSW × 7 kA** e curva térmica do MDWH não puderam ser verificadas com o material da pasta.
- **CCM1/2/3/6 (5ª rodada) — interpretações de enunciado:** motores de dupla tensão (380/660 V) e de quádrupla tensão (220/380/440/760 V) assumidos para Y-Δ e série-paralela; P22 lido como redução 3:1 com motor de 45 kW (50 cv na planta × 30 cv na ‘dica’); P23 com TAP 65 %; P24 intermitente com 1/3 de ventilação no repouso; potências de P18, P19, P20 e P24 lidas do DWG; CCM6 com alimentador ACW800U e 800 mm² equivalentes (cabos em paralelo). Cenários de sensibilidade não repetidos para estes quatro CCMs.
- **Não renderizei o DOCX/XLSX em Word/Excel** (sem Office/LibreOffice disponíveis): validação por XML, por motor de fórmulas em Python e por conferência numérica; falta um olhar humano sobre diagramação e atualizar o sumário (campos).